# created by ACA

from storage import *


def handler_name(event, context):
    print('Received Event: {}'.format(event))
    bucket = event['Records'][0]['s3']['bucket']['name']
    objectName = event['Records'][0]['s3']['object']['key']
    objectSize = event['Records'][0]['s3']['object']['size']
    print(objectName)
    print("----  WELCOME ----")
    transferFileFromS3toGcs(bucket, objectName, objectSize)
    return "OK RETURN"
