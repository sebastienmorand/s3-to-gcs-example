"""
Config file
"""
import os

#config
# HOSTNAME = 'hostname.appspot.com'
# PROJECT_ID = "project-id"
# CLIENT_ID = '988845227823-818gkfoo4v494dphf6ll3hpqvibc4tif.apps.googleusercontent.com"'
# CLIENT_SECRET = 'pTrX2C2HRVy962w1zslN3arz'
SERVICE_ACCOUNT_EMAIL = "test-gcs@gbl-imt-ve-dfcasbigquery-test.iam.gserviceaccount.com"
TECH_ACCOUNT = "ccoe-gapps.technical@veolia.com"
EMAIL = "ccoe-gapps.technical@veolia.com"
DOMAIN = 'veolia.com'
SERVICE_ACCOUNT_JSON_FILE_PATH = os.path.dirname(__file__) + "/gbl-imt-ve-digitalfactory-test-31b586734858.json"
LOGS_API_URL = "https://apps-logs.appspot.com/_ah/api"
ENVIRONMENT = "prod"
