__author__ = 'Acastex'


import datetime
import logging
from server.api.oauth import OAuth
from server.config import *


API = "logs"
VERSION = "v1"
OAUTH_SCOPE = ["https://www.googleapis.com/auth/userinfo.email"]

def insertLogs(email, action, description, status, user, kpi=False):
    """
    Insertion of a log in the Log Dev Team App
    :param email: TECH ACCOUNT for the request to the API
    :param action: Action type  with number in order  ex 1-Update
    :param description: Short description of what we do   ex Updating list of departments
    :param status: Only 3 Status allowed SUCCESS , ERROR, USER_FAILURE
    :param user: User concerned by the action
    :param kpi: True if there is a KPI action
    :return: log of the action
    """
    dateNow = str(datetime.datetime.today())
    parameters = {
    "app": PROJECT_ID,
    "action": action,
    "date": dateNow,
    "description": description,
    "status": status,
    "kpi": kpi,
     "user": user}
    api_root = LOGS_API_URL
    discovery_url = '%s/discovery/v1/apis/%s/%s/rest' % (api_root, API, VERSION)
    result = OAuth.backoffExec(OAuth.getServiceBakcendAPI(email, API, VERSION, OAUTH_SCOPE, discovery_url).insert(body=parameters))
    logging.info(result)
    # return result

